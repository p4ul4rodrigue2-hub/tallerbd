CREATE DATABASE IF NO EXISTS comprayventa;

CREATE TABLE IF NO EXISTS usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    documento VARCHAR(25) NOT NULL UNIQUE,
    nombre VARCHAR(50) NOT NULL,
    email VARCHAR(50),
    telefono VARCHAR(25)
);

CREATE TABLE IF NOT EXISTS vehiculos (
    id_vehiculos INT AUTO_INCREMENT PRIMARY KEY,
    placa VARCHAR(25) NOT NULL UNIQUE,
    marca VARCHAR(50) NOT NULL,
    modelo VARCHAR(50) NOT NULL,
    anio INT NOT NULL
);

CREATE TABLE IF NOT EXISTS transaccion (
    id_transaccion INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    id_vehiculos INT,
    tipo ENUM('compra', 'venta') NOT NULL,
    precio DECIMAL(12,2) NOT NULL,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE RESTRICT,
    FOREIGN KEY (id_vehiculos) REFERENCES vehiculos(id_vehiculos) ON DELETE RESTRICT
);


