
let editando = false;
let idEditar = null;

const formulario = document.getElementById('form-vehiculo');
const tablaBody = document.getElementById('lista-vehiculos');
const inputBusqueda = document.getElementById('inputBusqueda');


async function cargarVehiculos() {
    try {
        const respuesta = await fetch('http://localhost:3000/api/vehiculos');
        const resultado = await respuesta.json();
        
        tablaBody.innerHTML = ''; 
        const listaFinal = Array.isArray(resultado) ? resultado : (resultado.data || []);

        listaFinal.forEach(v => {
            const fila = document.createElement('tr');
            fila.innerHTML = `
                <td>${v.placa}</td>
                <td>${v.marca}</td>
                <td>${v.modelo}</td>
                <td>${v.anio || v.año}</td>
                <td>
                    <button onclick="prepararEdicion('${v.id_vehiculos}', '${v.placa}', '${v.marca}', '${v.modelo}', '${v.anio || v.año}')" style="background-color: #f39c12; color: white; border: none; padding: 5px 10px; cursor: pointer; border-radius: 4px; margin-right: 5px;">
                        Editar
                    </button>
                    <button onclick="eliminarVehiculo(${v.id_vehiculos})" style="background-color: #ff4d4d; color: white; border: none; padding: 5px 10px; cursor: pointer; border-radius: 4px;">
                        Eliminar
                    </button>
                </td>
            `;
            tablaBody.appendChild(fila);
        });
    } catch (error) {
        console.error("Error al cargar la tabla:", error);
    }
}


formulario.addEventListener('submit', async (e) => {
    e.preventDefault(); 

    const datosVehiculo = {
        placa: document.getElementById('placa').value,
        marca: document.getElementById('marca').value,
        modelo: document.getElementById('modelo').value,
        anio: document.getElementById('anio').value
    };

    try {
        const url = editando 
            ? `http://localhost:3000/api/vehiculos/${idEditar}` 
            : 'http://localhost:3000/api/vehiculos';
        
        const metodo = editando ? 'PUT' : 'POST';

        const respuesta = await fetch(url, {
            method: metodo,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(datosVehiculo)
        });

        const resultado = await respuesta.json();

        if (resultado.success) {
            alert(editando ? '🔄 ¡Vehículo actualizado!' : '🚗 ¡Vehículo guardado!');
            restablecerFormulario();
            cargarVehiculos(); 
        }
    } catch (error) {
        console.error("Error en la operación:", error);
    }
});


function prepararEdicion(id, placa, marca, modelo, anio) {
    document.getElementById('placa').value = placa;
    document.getElementById('marca').value = marca;
    document.getElementById('modelo').value = modelo;
    document.getElementById('anio').value = anio;

    editando = true;
    idEditar = id;
    document.querySelector('#form-vehiculo button').textContent = "Actualizar Vehículo";
    window.scrollTo(0, 0); 
}


async function eliminarVehiculo(id) {
    if (confirm('¿Estás seguro de que quieres eliminar este vehículo?')) {
        try {
            const respuesta = await fetch(`http://localhost:3000/api/vehiculos/${id}`, {
                method: 'DELETE'
            });
            const resultado = await respuesta.json();
            if (resultado.success) {
                alert('🗑️ Eliminado');
                cargarVehiculos(); 
            }
        } catch (error) {
            console.error("Error al eliminar:", error);
        }
    }
}


inputBusqueda.addEventListener('keyup', () => {
    const valor = inputBusqueda.value.toLowerCase();
    const filas = document.querySelectorAll('#lista-vehiculos tr');
    filas.forEach(fila => {
        const contenido = fila.textContent.toLowerCase();
        fila.style.display = contenido.includes(valor) ? '' : 'none';
    });
});


function restablecerFormulario() {
    formulario.reset();
    editando = false;
    idEditar = null;
    document.querySelector('#form-vehiculo button').textContent = "Guardar Vehículo";
}

document.addEventListener('DOMContentLoaded', cargarVehiculos);