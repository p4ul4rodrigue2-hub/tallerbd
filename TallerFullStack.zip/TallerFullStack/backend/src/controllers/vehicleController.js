const db = require('../config/db');

const getAllVehicles = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM vehiculos');
        res.json({ success: true, data: rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const createVehicle = async (req, res) => {
    const { placa, marca, modelo, anio } = req.body;
    try {
        const sql = 'INSERT INTO vehiculos (placa, marca, modelo, anio) VALUES (?, ?, ?, ?)';
        await db.query(sql, [placa, marca, modelo, anio]);
        res.status(201).json({ success: true, message: 'Vehículo creado' });
    } catch (error) {
        res.status(400).json({ success: false, error: error.message });
    }
};


module.exports = {
    getAllVehicles,
    createVehicle,
    getVehicleByPlate: (req, res) => {},
    updateVehicle: (req, res) => {},
    deleteVehicle: (req, res) => {}
};