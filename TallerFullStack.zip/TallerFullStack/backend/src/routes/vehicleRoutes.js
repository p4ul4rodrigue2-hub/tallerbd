const express = require('express');
const router = express.Router();
const vehicleController = require('../controllers/vehicleController');

router.get('/', vehicleController.getAllVehicles);

router.get('/:placa', vehicleController.getVehicleByPlate);

router.post('/', vehicleController.createVehicle); 


router.put('/:id_vehiculos', vehicleController.updateVehicle); 
router.delete('/:id_vehiculos', vehicleController.deleteVehicle); 

module.exports = router;