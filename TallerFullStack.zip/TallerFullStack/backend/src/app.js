
require('dotenv').config(); 
const express = require('express');
const cors = require('cors');
const db = require('./config/db'); 


const vehicleRoutes = require('./routes/vehicleRoutes'); 

const app = express();
-
app.use(cors());
app.use(express.json()); 


app.use('/api/vehiculos', vehicleRoutes); 

app.get('/', (req, res) => {
    res.send('🚗 ¡Servidor de AutoMarket Pro funcionando!');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Servidor en http://localhost:${PORT}`);
});